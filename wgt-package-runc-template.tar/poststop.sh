#!/bin/bash

if [ $# -ne 1 ]; then
    exit 1
fi

#get container installation directory
container_dir=$1

#unmount layered file system
umount $container_dir/rootfs

#delete all temporary folders
rm -rf $container_dir/rw_layer
rm -rf $container_dir/workdir
rm -rf $container_dir/rootfs
