#!/bin/bash

if [ $# -ne 1 ]; then
    exit 1
fi

#get container installation directory
container_dir=$1

#create rootfs directory
mkdir -p $container_dir/rootfs

#create temporary directories
mkdir -p $container_dir/rw_layer
mkdir -p $container_dir/workdir

#mount layered file system
mount -t overlay -o lowerdir=/:$container_dir/app,upperdir=$container_dir/rw_layer,workdir=$container_dir/workdir overlay $container_dir/rootfs
